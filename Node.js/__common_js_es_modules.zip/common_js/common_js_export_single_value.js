// CommonJS syntax
// logger.js

function logger(message) {
  console.log(message);  
}

// Exporting a default function
module.exports = logger;
