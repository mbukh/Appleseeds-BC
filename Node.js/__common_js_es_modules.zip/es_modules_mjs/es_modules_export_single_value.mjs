// ES module syntax

function logger(message) {
  console.log(message);
}

// Exporting a default function
export default logger;