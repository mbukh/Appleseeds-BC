import React from "react";
import { Record } from "./Record.component";

export const RecordList = () => {};
