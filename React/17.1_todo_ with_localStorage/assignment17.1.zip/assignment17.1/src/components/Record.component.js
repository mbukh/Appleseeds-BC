import React from "react";

export const Record = () => {
  return <div>Record</div>;
};
