const Input = () => {
  return (
    <div className="Input-container">
      <input type="text" placeholder="Search by name..." name="search" />
      <button>Add</button>
    </div>
  );
};
export default Input;
